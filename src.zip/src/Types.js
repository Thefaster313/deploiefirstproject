export const Add_reminder='Add_reminder'
export const Remove_reminder='Remove_reminder'
export const Clear_reminder='Clear_reminder'
